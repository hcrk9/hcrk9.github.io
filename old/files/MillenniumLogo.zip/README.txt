千年标志 MILLENNIUM LOGO
v1.00
by Hachi @ hachiiiiiiii.co

LICENSE
CC BY-NC 4.0
您可在署名，非商业的基础上对附带的矢量文件进行修改和再分发。