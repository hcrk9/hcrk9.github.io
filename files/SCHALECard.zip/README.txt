夏莱ID卡 S.C.H.A.L.E ID CARD
v1.00 - Rev. 23.4.15
by Hachi @ hachiiiiiiii.co

LICENSE
CC BY-NC 4.0
您可在署名，非商业的基础上对附带的矢量文件和Figma源文件进行修改和再分发。