「蔚蓝档案」柚箱 / BlueArchive Yuzu Box
v1.00 - Rev. 23.11.10
Designed by Hachi @ hachiiiiiiii.co

推荐使用矢量格式（SVG）。

LICENSE: CC BY-NC 4.0
您可在署名，非商业的基础上对附带的矢量或位图文件进行修改和再分发。