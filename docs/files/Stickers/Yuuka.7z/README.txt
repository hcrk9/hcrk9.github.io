硬盘贴纸 Drive Sticker
v1
by Hachi @ hachiiiiiiii.co

LICENSE
CC BY-NC 4.0
您可在署名，非商业的基础上对附带的矢量文件和Figma源文件进行修改和再分发。

*版权内容 © NEXON Games